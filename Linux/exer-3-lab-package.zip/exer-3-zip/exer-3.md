# Exer-3: Practice Exercises

---

## Exercise 1 — Creating and Removing Directories and Files
Create a directory structure `app/config`, `app/logs`, `app/data`, then remove only `app/logs`.

---

## Exercise 2 — Creating New Files
Create three files representing a mini project: `README.md`, `main.sh`, `config.txt`, then verify with `ls -l`.

---

## Exercise 3 — Editing Files Using Vim
Edit `README.md` in vim to add a title and a description line.

---

## Exercise 4 — Copy and Move Files and Directories
Copy your `app/` directory into `backup/`, then rename `backup/app` to `backup/app_v1`.

---

## Exercise 5 — Reading Files
Given a 100-line sample log file, find the last 15 lines and the first 10 lines, then watch it live with `tail -f` while new entries are appended.

---

## Exercise 6 — Filtering Text Using grep
Using the sample log file, find all lines containing "warning", count them, then find all lines that do NOT contain "info".
