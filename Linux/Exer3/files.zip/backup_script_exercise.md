# Exercise: Debugging a Runaway Backup Script

You're given a script called `backup.sh` that a teammate says "sometimes hangs
and fills up disk space." Your job, using only the terminal:

1. Start it in the background so it doesn't block your terminal, and note its PID.
2. Confirm it's actually running using `ps`.
3. While it runs, execute `ls` on the backup folder — redirect the successful
   output to `success.log` and any errors to `error.log`, in the same command.
4. Let it run for a few seconds, then simulate it "hanging" by leaving it alive
   — check its status again with `ps -e`.
5. Kill it gracefully first; if it doesn't die, force-kill it using the PID.
6. Combine `success.log` and `error.log` into a single file called `report.log`,
   in that order, using `cat`.
7. Finally, pipe the contents of `report.log` through `cat` one more time and
   redirect that into `final_report.txt` — so the whole chain
   (run → capture → merge → confirm) is provable from file listing alone
   (`ls`) at the end.

## Submission

Submit the exact sequence of commands you typed, plus the final `ls` output
showing all the files you created.
