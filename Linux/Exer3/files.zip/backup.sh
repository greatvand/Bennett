#!/bin/bash
echo "Starting backup..."
sleep 60
echo "Backup complete"
